import { Component, OnInit, computed, inject, input, output, signal } from '@angular/core';
import { extractApiError, formatDate } from '../routines/routine.utils';
import { DAY_LABELS, Enrollment, GymClass } from './classes.models';
import { toIsoDate } from './date.utils';
import { EnrollmentService } from './enrollment.service';

type StudentsScope = 'today' | 'all';

@Component({
  selector: 'app-class-students',
  standalone: true,
  templateUrl: './class-students.html',
  styleUrls: ['./class-modal.css', './class-students.css'],
  host: { '(document:keydown.escape)': 'close()' }
})
export class ClassStudents implements OnInit {
  private readonly enrollmentService = inject(EnrollmentService);

  readonly gymClass = input.required<GymClass>();
  readonly closed = output<void>();

  protected readonly isLoading = signal<boolean>(true);
  protected readonly errorMessage = signal<string | null>(null);
  protected readonly enrollments = signal<Enrollment[]>([]);
  protected readonly scope = signal<StudentsScope>('today');

  /** Inscripciones de esta clase según el alcance elegido, ordenadas por apellido. */
  protected readonly visible = computed(() => {
    const today = toIsoDate(new Date());
    const list =
      this.scope() === 'today'
        ? this.enrollments().filter((e) => e.enrollmentDate === today)
        : this.enrollments();
    return [...list].sort((a, b) =>
      (a.client?.lastName ?? '').localeCompare(b.client?.lastName ?? '', 'es')
    );
  });

  protected readonly formatDate = formatDate;

  ngOnInit(): void {
    this.load();
  }

  protected load(): void {
    this.isLoading.set(true);
    this.errorMessage.set(null);
    // El back no tiene un endpoint por clase: se pide el listado completo y se filtra acá.
    this.enrollmentService.getAll().subscribe({
      next: (list) => {
        const classId = this.gymClass().externalId;
        this.enrollments.set(list.filter((e) => e.gymClass?.externalId === classId));
        this.isLoading.set(false);
      },
      error: (err) => {
        this.isLoading.set(false);
        this.errorMessage.set(extractApiError(err, 'No se pudo cargar la lista de alumnos.'));
      }
    });
  }

  protected setScope(scope: StudentsScope): void {
    this.scope.set(scope);
  }

  protected close(): void {
    this.closed.emit();
  }

  protected dayLabel(c: GymClass): string {
    return DAY_LABELS[c.dayOfWeek];
  }

  protected time(value: string): string {
    return value.slice(0, 5);
  }
}
