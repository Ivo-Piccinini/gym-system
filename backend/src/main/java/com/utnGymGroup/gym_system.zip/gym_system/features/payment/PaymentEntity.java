package com.utnGymGroup.gym_system.features.payment;

import com.utnGymGroup.gym_system.features.subscription.SubscriptionEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "payments")
public class PaymentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "public_id", unique = true)
    private UUID publicId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subscription_id", nullable = false)
    private SubscriptionEntity subscription;

    private Double amount;

    @Column(name = "payment_date")
    private LocalDate paymentDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "method")
    private PaymentMethods method;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private PaymentStatus status;

    @Column(name = "validated_by")
    private String validatedBy;

    @Column(name = "validation_date")
    private LocalDateTime validationDate;

    @PrePersist
    void onCreate() {
        if (this.publicId == null) {
            this.publicId = UUID.randomUUID();
        }
        if (this.status == null) {
            if (this.method == PaymentMethods.TARJETA) {
                this.status = PaymentStatus.APPROVED;
                this.validatedBy = "SISTEMA";
                this.validationDate = LocalDateTime.now();
            } else {
                this.status = PaymentStatus.PENDING;
            }
        }
    }
}
